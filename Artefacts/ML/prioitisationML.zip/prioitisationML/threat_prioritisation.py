#!/usr/bin/env python
# coding: utf-8

import sys
import pickle
import json
import pandas as pd
import requests
import re
import os
import pandas as pd
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.models import Sequential
from keras.layers import Dense, Embedding, LSTM, SpatialDropout1D
from sklearn.model_selection import train_test_split
from keras.utils.np_utils import to_categorical
from keras.callbacks import EarlyStopping
from keras.layers import Dropout
from nltk.corpus import stopwords
from nltk import word_tokenize
import nltk
from nltk.corpus import stopwords
from nltk.stem.snowball import SnowballStemmer
import tensorflow as tf
from sqlalchemy import create_engine


# In[61]:


#API Call get data from NIST 
def getdata(industry):
    response = requests.get("https://services.nvd.nist.gov/rest/json/cves/1.0/?resultsPerPage=2000&keyword="+industry)
    Dictionary = response.json()
    id_ = []
    description = []
    score = []
    published_ = []
    lastModified_ = []
    dict_ = Dictionary['result']['CVE_Items']
    for element in dict_:
        id_.append(element['cve']['CVE_data_meta']['ID'])
        for i in element['cve']['description']['description_data']:
            description.append(i['value'])
        score.append(element['impact'])
        published_.append(element['publishedDate'])
        lastModified_.append(element['lastModifiedDate'])
        
    lists = [id_, description, score, published_, lastModified_]
    df = pd.DataFrame(lists).transpose()
    df.columns = ['CVE_ID', 'description','score','published_','lastModified']
    
    df = df[df.score != {}]
    df.reset_index(drop=True, inplace=True)
    df_score = df["score"].apply(pd.Series)
    df_metricV3 = df_score["baseMetricV3"].apply(pd.Series)
    df_cvssV3 = df_metricV3["cvssV3"].apply(pd.Series)
    result_df = pd.concat([df, df_cvssV3], axis=1)
    return result_df


# Get data by different industries

# Administrative
AS = getdata('administrative service')
AS.drop(AS[AS['attackComplexity'].isnull() == True].index, inplace=True)
AS['Industry'] = 'administration'

# Accommodation and food services
#'accommodation' or 'food' or 'beverage' or 'hotel' or 'catering' or 'hospitality',
Food = getdata('food')
Beverage = getdata('beverage')
Hotel = getdata('hotel')
Catering = getdata('catering')
Hospitality = getdata('hospitality')
Accom_food = pd.concat([Food, Beverage, Hotel, Catering, Hospitality], ignore_index=True, sort=True)
Accom_food.drop(Accom_food[Accom_food['attackComplexity'].isnull() == True].index, inplace=True)
Accom_food['Industry'] = 'hospitality'

#Agriculture, Forestry & Fisheries
Agri = getdata('agriculture') 
Farm = getdata('farm') 
Agri_Forest_Fish = pd.concat([Agri, Farm], ignore_index=True, sort=True)
Agri_Forest_Fish.drop(Agri_Forest_Fish[Agri_Forest_Fish['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
Agri_Forest_Fish['Industry'] = 'agriculture'

#Education 
education = getdata('education') 
student = getdata('student')
uni = getdata('university')
insti = getdata('institute')
school = getdata('school')
education_industry = pd.concat([education, student, uni, insti, school], ignore_index=True, sort=True)
education_industry.drop(education_industry[education_industry['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
education_industry['Industry'] = 'education'

#Finance Industry
#'financial' or 'bank' or 'insurance' or 'finance'
financial = getdata('financial') 
bank = getdata('bank')
insurance = getdata('insurance')
finance = getdata('finance')
investment = getdata('investment')
loan = getdata('loan')
mortgage = getdata('mortgage')
wallet = getdata('wallet')
forex = getdata('forex')
treasury = getdata('treasury')
cryptocurrency = getdata('cryptocurrency')

finance_industry = pd.concat([financial, bank, uni, insurance, finance, investment, 
                              loan, mortgage, wallet, forex, treasury,cryptocurrency],
                             ignore_index=True, sort=True)
finance_industry.drop(finance_industry[finance_industry['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
finance_industry['Industry'] = 'finance'

#Government
government = getdata('government')
government.drop(government[government['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
government['Industry'] = 'government'


#Health & Medical
health = getdata('health')
medical = getdata('medical')
hospital = getdata('hospital')
clinic = getdata('clinic')
nurse = getdata('nursing')
patient = getdata('patient')
health_industry = pd.concat([health, medical, hospital, clinic, nurse, 
                              patient],
                             ignore_index=True, sort=True)
health_industry.drop(health_industry[health_industry['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
health_industry['Industry'] = 'healthcare'

#Rental, real estate & hiring
rental = getdata('rental')
real_es = getdata('real estate')
rental_real = pd.concat([rental, real_es],
                             ignore_index=True, sort=True)
rental_real.drop(rental_real[rental_real['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
rental_real['Industry'] = 'realestate'

#Retail Wholesale
retail = getdata('retail')
wholesale = getdata('wholesale')
supplier = getdata('supplier')
retail_wholesale = pd.concat([retail, wholesale,supplier],
                             ignore_index=True, sort=True)
retail_wholesale.drop(retail_wholesale[retail_wholesale['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
retail_wholesale['Industry'] = 'retail'

#Tourism
tourism = getdata('tourism')
travel = getdata('travel')
tour_indus = pd.concat([tourism, travel],
                             ignore_index=True, sort=True)
tour_indus.drop(tour_indus[tour_indus['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
tour_indus['Industry'] = 'tourism'

#Postal
postal = getdata('postal')
warehouse = getdata('warehouse')
airline = getdata('airline')
bus = getdata('bus booking')
ticket = getdata('bus ticket')
air_cargo = getdata('air cargo')
postal_warehouse_transport = pd.concat([postal, warehouse, airline, bus, ticket, air_cargo],
                             ignore_index=True, sort=True)
postal_warehouse_transport.drop(postal_warehouse_transport[postal_warehouse_transport['attackComplexity'].isnull() 
                                                           == True].index, inplace=True)
postal_warehouse_transport['Industry'] = 'transportation'

#Telecom
telecom = getdata('telecom')
telecom.drop(telecom[telecom['attackComplexity'].isnull() == True].index, inplace=True)
telecom['Industry'] = 'telecommunication'

#Manufacturing industry
PLM = getdata("Oracle Agile PLM")
PLM.drop(PLM[PLM['attackComplexity'].isnull() == True].index, inplace=True)
PLM['Industry'] = 'manufacturing'

#Concatenate all dataframe (of different industry)
df = pd.concat([AS, Accom_food, Agri_Forest_Fish, education_industry, finance_industry,
               government, health_industry, rental_real, retail_wholesale, tour_indus,
               postal_warehouse_transport, telecom, PLM], ignore_index=True, sort=True)
df.reset_index(drop=True, inplace=True)

# Categorize the data into different vulnerability type
cond_list = [df['description'].str.contains('denial of service' or 'flood attack' or 'denial-of-service', case=False),
             df['description'].str.contains('buffer overflow' or ('buffer' and 'overwrite') or
             'stack overflow' or 'buffer over-read' or 'heap overflow' or 'heap-buffer-overflow' 
            or 'integer overflow' or 'heap-overflow',case=False),
             df['description'].str.contains('code execution' or 'command execution' or
             ('execute' and 'arbitrary' and ('code' or 'command')) or ('execute' and ('code' or 'command')), case=False),
             df['description'].str.contains('memory consumption issue' or ('memory' and 'corrupt'), case=False),
             df['description'].str.contains(('sql' and 'inject'), case=False),
             df['description'].str.contains('XSS' or ('cross' and 'site') or 'Cross-Site Scripting' or 'Cross-site Scripting', case=False),
             df['description'].str.contains('Directory Traversal' or 'Path traversal' or 
             ('InHand Networks InRouter 900 Industrial 4G Router before v1.0.0.r11700' and 'arbitrary') or
             ('Jenkins' and 'permission' and 'arbitrary'), case=False),
             df['description'].str.contains('Http Response Splitting' or ('request' and 'splitting'), case=False),
             df['description'].str.contains('Bypass', case=False),
             df['description'].str.contains('information disclosure' or 'gain information' or 'information exposure', case=False),
              df['description'].str.contains(('gain' and 'privilege') or 'privileged' or 'user privilege' or
              'privilege escalation' or ('unprivileged' and ('user' or 'attacker' or 'actor')), case=False),
              df['description'].str.contains('CSRF' or 'Cross-site request forgery', case=False),
              df['description'].str.contains('LFI' or ('file' and 'inclusion'), case=False)
             ]
choice_list = ['Denial of Service', 'Buffer Overflow', 'Code Execution', 'Memory Corruption', 'SQL injection', 
'XSS', 'Directory Traversal', 'Http Response Splitting', 'Bypass', 'Gain Information', 'Gain Privilege', 'CSRF', 'File Inclusion']

df['Denial of Service'] = np.where(cond_list[0], True, False)
df['Buffer Overflow'] = np.where(cond_list[1], True, False)
df['Code Execution'] = np.where(cond_list[2], True, False)
df['Memory Corruption'] = np.where(cond_list[3], True, False)
df['SQL Injection'] = np.where(cond_list[4], True, False)
df['XSS'] = np.where(cond_list[5], True, False)
df['Directory Traversal'] = np.where(cond_list[6], True, False)
df['Http Response Splitting'] = np.where(cond_list[7], True, False)
df['Bypass'] = np.where(cond_list[8], True, False)
df['Gain Information'] = np.where(cond_list[9], True, False)
df['Gain Privilege'] = np.where(cond_list[10], True, False)
df['CSRF'] = np.where(cond_list[11], True, False)
df['File Inclusion'] = np.where(cond_list[12], True, False)


#Assign Severity
df['Severity Score'] = df['baseSeverity'].map({'LOW': 1,
                                            'MEDIUM': 2,
                                            'HIGH': 3,
                                            'CRITICAL': 4})
print(df)

# Insert MISP data

#Database connection credentials
username = os.environ.get('MySQLroot')
password = os.environ.get('MySQLrootpw')
hostname = 'localhost'
dbname = 'securemation'


#Create SQLAlchemy engine to connect to mySQL db
engine = create_engine("mysql+pymysql://{user}:{pw}@{host}/{db}"
                      .format(host=hostname, db=dbname, user=username, pw=password))
dbConnection = engine.connect()


MISP_cve = pd.read_sql("select * from securemation.misp_map", dbConnection);


# Get the CVSS score from NVD API by CVE ID
def getscore(id):
    response = requests.get("https://services.nvd.nist.gov/rest/json/cve/1.0/"+ id + "?addOns=dictionaryCpes")
    Dictionary = response.json()
    id_ = []
    description = []
    score = []
    dict_ = Dictionary['result']['CVE_Items']
    for element in dict_:
        id_.append(element['cve']['CVE_data_meta']['ID'])
        for i in element['cve']['description']['description_data']:
            description.append(i['value'])
        if "baseMetricV3" in element['impact']:
            score.append(element['impact'])
        else:
            score.append({'baseMetricV3': {'cvssV3': {'version': '3.1','vectorString': 'NULL',
                                                  'attackVector': 'NULL','attackComplexity': 'NULL',
                                                  'privilegesRequired': 'NULL','userInteraction': 'NULL',
                                                  'scope': 'NULL','confidentialityImpact': 'NULL',
                                                  'integrityImpact': 'NULL','availabilityImpact': 'NULL',
                                                  'baseScore': 0,'baseSeverity': 'NULL'},
                                       'exploitabilityScore': 0,'impactScore': 0}})
        
    lists = [id_, description, score]
    df = pd.DataFrame(lists).transpose()
    df.columns = ['CVE_ID', 'description','score']
    
    df = df[df.score != {}]
    df.reset_index(drop=True, inplace=True)
    df_score = df["score"].apply(pd.Series)
    df_metricV3 = df_score["baseMetricV3"].apply(pd.Series)
    df_cvssV3 = df_metricV3["cvssV3"].apply(pd.Series)
    result_df = pd.concat([df, df_cvssV3], axis=1)
    return result_df


# Get the score and Merge all the result dataframes
df_new = []
for i in range(len(MISP_cve)):
    df_new.append(getscore(MISP_cve['CVE_ID'][i]))

appended_data = pd.concat(df_new)

MISP = appended_data.reset_index(drop = True)
print(MISP)

df_misp_mapped = pd.concat([MISP_cve, MISP], axis=1)
df_misp_mapped.loc[df_misp_mapped['baseSeverity'] == 'NULL']
df_misp_mapped['MISP Severity Score'] = df_misp_mapped['Threat_lvl'].map({1: 3,
                                            2: 2,
                                            3: 1,
                                            4: 0})
df_misp_mapped['misp-multiplier'] = df_misp_mapped['MISP Severity Score']* (0.01 * df_misp_mapped['Attribute_count'])
df_misp_mapped = df_misp_mapped[['CVE_ID', 'Attribute_count', 'Industry', 'description','baseSeverity','MISP Severity Score', 'misp-multiplier']]
df_misp_mapped = df_misp_mapped.reset_index(drop = True)
df_misp_mapped = df_misp_mapped.T.drop_duplicates().T

#Categorize the data into different vulnerabilities type

cond_list = [df_misp_mapped['description'].str.contains('denial of service' or 'flood attack' or 'denial-of-service', case=False),
             df_misp_mapped['description'].str.contains('buffer overflow' or ('buffer' and 'overwrite') or
             'stack overflow' or 'buffer over-read' or 'heap overflow' or 'heap-buffer-overflow' 
            or 'integer overflow' or 'heap-overflow',case=False),
             df_misp_mapped['description'].str.contains('code execution' or 'command execution' or
             ('execute' and 'arbitrary' and ('code' or 'command')) or ('execute' and ('code' or 'command')), case=False),
             df_misp_mapped['description'].str.contains('memory consumption issue' or ('memory' and 'corrupt'), case=False),
             df_misp_mapped['description'].str.contains(('sql' and 'inject'), case=False),
             df_misp_mapped['description'].str.contains('XSS' or ('cross' and 'site') or 'Cross-Site Scripting' or 'Cross-site Scripting', case=False),
             df_misp_mapped['description'].str.contains('Directory Traversal' or 'Path traversal' or 
             ('InHand Networks InRouter 900 Industrial 4G Router before v1.0.0.r11700' and 'arbitrary') or
             ('Jenkins' and 'permission' and 'arbitrary'), case=False),
             df_misp_mapped['description'].str.contains('Http Response Splitting' or ('request' and 'splitting'), case=False),
             df_misp_mapped['description'].str.contains('Bypass', case=False),
             df_misp_mapped['description'].str.contains('gain information' or ('information' and 'leak') or 
             'information exposure' or 'information disclosure', case=False),
              df_misp_mapped['description'].str.contains(('gain' and 'privilege') or 'privileged' or 'user privilege' or
              'privilege escalation' or ('unprivileged' and ('user' or 'attacker' or 'actor')), case=False),
              df_misp_mapped['description'].str.contains('CSRF' or 'Cross-site request forgery', case=False),
              df_misp_mapped['description'].str.contains('LFI' or ('file' and 'inclusion'), case=False)
             ]
choice_list = ['Denial of Service', 'Buffer Overflow', 'Code Execution', 'Memory Corruption', 'SQL injection', 
'XSS', 'Directory Traversal', 'Http Response Splitting', 'Bypass', 'Gain Information', 'Gain Privilege', 'CSRF', 'File Inclusion']


df_misp_mapped['Denial of Service'] = np.where(cond_list[0], True, False)
df_misp_mapped['Buffer Overflow'] = np.where(cond_list[1], True, False)
df_misp_mapped['Code Execution'] = np.where(cond_list[2], True, False)
df_misp_mapped['Memory Corruption'] = np.where(cond_list[3], True, False)
df_misp_mapped['SQL Injection'] = np.where(cond_list[4], True, False)
df_misp_mapped['XSS'] = np.where(cond_list[5], True, False)
df_misp_mapped['Directory Traversal'] = np.where(cond_list[6], True, False)
df_misp_mapped['Http Response Splitting'] = np.where(cond_list[7], True, False)
df_misp_mapped['Bypass'] = np.where(cond_list[8], True, False)
df_misp_mapped['Gain Information'] = np.where(cond_list[9], True, False)
df_misp_mapped['Gain Privilege'] = np.where(cond_list[10], True, False)
df_misp_mapped['CSRF'] = np.where(cond_list[11], True, False)
df_misp_mapped['File Inclusion'] = np.where(cond_list[12], True, False)

print(df_misp_mapped)

# ### Keywords for threat categories 
# 1. Denial of Service         
# 2. SQL injection             
# 3. Gain Privilege            
# 4. Buffer Overflow           
# 5. Bypass                    
# 6. XSS                       
# 7. Code Execution            
# 8. Directory Traversal       
# 9. CSRF                      
# 10. File Inclusion            
# 11. Http Response Splitting   
# 12. Gain Information          
# 13. Memory Corruption  
# 
# ### Keywords for Categorization of Industry
# 1. Accommodation & food services industry - 'accommodation'; 'food'; 'beverage'; 'hotel'; 'catering'; 'hospitality'
# 2. Administrative and support services industry - 'administrative service'; 'support service'
# 3. Agriculture, Forestry and Fisheries industry - 'agriculture'; 'forestry'; 'fisheries'
# 4. Financial and insurance services industry - 'financial'; 'bank'; 'insurance'; 'finance'
# 5. Health and medical industry - 'health'; 'medical'; 'hospital'
# 6. Rental, hiring and real estate services industry - 'rental'; 'real estate'
# 7. Retail and wholesale trade industry - 'retail'; 'wholesale'
# 8. Tourism industry - 'tourism'
# 9. Transport, postal and warehousing industry - 'postal'; 'warehouse'; 'airline'
# 10. Government - 'government'
# 11. Utilities - 'Information Media'; 'Telecommunications'
# 12. Education industry - 'education'
# 13. Arts and recreation services industry
# 14. Building and construction industry
# 15. Mining and heavy industry
# 16. Manufacturing industry
# 17. Professional, scientific and technical services industry
# 
# #### E.g.
# #### Buffer overflow in NFS mountd gives root access to remote attackers, mostly in Linux systems.
# #### Information from SSL-encrypted sessions via PKCS #1.
# #### Arbitrary command execution via IMAP buffer overflow in authenticate command.


# Define function for preprocessing the description column

def decontract(sentence):
    # specific
    sentence = re.sub(r"won't", "will not", sentence)
    sentence = re.sub(r"can\'t", "can not", sentence)

    # general
    sentence = re.sub(r"n\'t", " not", sentence)
    sentence = re.sub(r"\'re", " are", sentence)
    sentence = re.sub(r"\'s", " is", sentence)
    sentence = re.sub(r"\'d", " would", sentence)
    sentence = re.sub(r"\'ll", " will", sentence)
    sentence = re.sub(r"\'t", " not", sentence)
    sentence = re.sub(r"\'ve", " have", sentence)
    sentence = re.sub(r"\'m", " am", sentence)
    return sentence

def cleanPunc(sentence): 
    cleaned = re.sub(r'[?|!|\'|"|#]',r'',sentence)
    cleaned = re.sub(r'[.|,|)|(|\|/]',r' ',cleaned)
    cleaned = cleaned.strip()
    cleaned = cleaned.replace("\n"," ")
    return cleaned

def keepAlpha(sentence):
    alpha_sent = ""
    for word in sentence.split():
        alpha_word = re.sub('[^a-z A-Z]+', '', word)
        alpha_sent += alpha_word
        alpha_sent += " "
    alpha_sent = alpha_sent.strip()
    return alpha_sent

from nltk.corpus import stopwords
stop = stopwords.words('english')

stemmer = SnowballStemmer("english")
def stemming(sentence):
    stemSentence = ""
    for word in sentence.split():
        stem = stemmer.stem(word)
        stemSentence += stem
        stemSentence += " "
    stemSentence = stemSentence.strip()
    return stemSentence


save_path = sys.path[0]
file_name = 'tf_cnnmodel'
modelsave = os.path.join(sys.path[0], file_name)
print(modelsave)


# Load the neural network model

new_model = tf.keras.models.load_model(modelsave)
new_model.summary()

# load the tokenizer
with open('tokenizer.pickle', 'rb') as handle:
    tokenizer1 = pickle.load(handle)


# Preprocess the description column

df_misp_mapped['description'] = df_misp_mapped['description'].str.lower()
df_misp_mapped['description'] = df_misp_mapped['description'].apply(decontract)
df_misp_mapped['description'] = df_misp_mapped['description'].apply(cleanPunc)
df_misp_mapped['description'] = df_misp_mapped['description'].apply(keepAlpha)
df_misp_mapped['description'] = df_misp_mapped['description'].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop)]))
df_misp_mapped['description'] = df_misp_mapped['description'].apply(stemming)


# Separate the dataframe into baseSeverity=NULL & baseSeverity != NULL

df_notnull = df_misp_mapped.loc[df_misp_mapped['baseSeverity'] != 'NULL']
df_null = df_misp_mapped.loc[df_misp_mapped['baseSeverity'] == 'NULL']
df_null = df_null.reset_index(drop = True)
print(df_null)


# Tokenize the description 
x = np.array(tokenizer1.texts_to_sequences(df_null['description'].tolist()) )
x = pad_sequences(x, padding='post', maxlen=200)


# Generate predictions (probabilities -- the output of the last layer)
# on test  data using `predict`
print("Generate predictions for all null data")
predictions = new_model.predict(x)
print(predictions)
predict_results = predictions.argmax(axis=1)


df_null['baseSeverity']= predict_results
df_null['baseSeverity'] = np.where((df_null.baseSeverity == 0),'CRITICAL',df_null.baseSeverity)
df_null['baseSeverity'] = np.where((df_null.baseSeverity == '1'),'HIGH',df_null.baseSeverity)
df_null['baseSeverity'] = np.where((df_null.baseSeverity == '2'),'LOW',df_null.baseSeverity)
df_null['baseSeverity'] = np.where((df_null.baseSeverity == '3'),'MEDIUM',df_null.baseSeverity)


df_misp_mapped = pd.concat([df_null, df_notnull], ignore_index=True)
df_misp_mapped['Severity Score'] = df_misp_mapped['baseSeverity'].map({'LOW': 1,
                                            'MEDIUM': 2,
                                            'HIGH': 3,
                                            'CRITICAL': 4})

df['misp-multiplier'] = 0
df_scoring = pd.concat([df[['CVE_ID', 'Industry', 'baseSeverity', 'Denial of Service', 'Buffer Overflow', 'Code Execution', 'Memory Corruption', 'SQL Injection', 
'XSS', 'Directory Traversal', 'Http Response Splitting', 'Bypass', 'Gain Information', 'Gain Privilege', 'CSRF', 'File Inclusion', 'Severity Score', 'misp-multiplier']], 
 df_misp_mapped[['CVE_ID', 'Industry', 'baseSeverity', 'Denial of Service', 'Buffer Overflow', 'Code Execution', 'Memory Corruption', 'SQL Injection', 
'XSS', 'Directory Traversal', 'Http Response Splitting', 'Bypass', 'Gain Information', 'Gain Privilege', 'CSRF', 'File Inclusion', 'Severity Score', 'misp-multiplier']]], 
                       ignore_index=True)
df_scoring


def scoring(df, ind):
    df_industry = df.loc[df['Industry']== ind]
    severity_score = []
    MISP_severity_score = []
    choice_list = ['Denial of Service', 'Buffer Overflow', 'Code Execution', 'Memory Corruption', 'SQL Injection', 
'XSS', 'Directory Traversal', 'Http Response Splitting', 'Bypass', 'Gain Information', 'Gain Privilege', 'CSRF', 'File Inclusion']
    for threat in choice_list:
        df_threat = df_industry.loc[df_industry[threat] == True][[threat, 'misp-multiplier','Severity Score']]
        values = df_threat['misp-multiplier'] * df_threat['Severity Score']
        df_threat['MISP Severity Score'] = values.where(df_threat['misp-multiplier'] != 0, other=df_threat['Severity Score'])
        MISP_severity_score.append(df_threat['MISP Severity Score'].sum())
        severity_score.append(df_threat['Severity Score'].sum())
    
    scoring = pd.DataFrame()
    scoring['threatType'] = choice_list
    scoring['severityScore'] = severity_score
    scoring['MISPSeverityScore'] = MISP_severity_score
    scoring = scoring.sort_values(by=['MISPSeverityScore'], ascending=False)   
    scoring.reset_index(drop=True, inplace=True)
    return scoring


industrylist = ['administration', 'hospitality', 'agriculture', 'finance', 'government', 'healthcare', 'realestate', 'retail', 'tourism', 'transportation', 'telecommunication', 'manufacturing', 'utilities']


#Database connection credentials
username = os.environ.get('MySQLroot')
password = os.environ.get('MySQLrootpw')
hostname = 'localhost'
dbname = 'securemation'

#Create SQLAlchemy engine to connect to mySQL db
engine = create_engine("mysql+pymysql://{user}:{pw}@{host}/{db}"
                      .format(host=hostname, db=dbname, user=username, pw=password))



for i in industrylist:
    print("Created MySQL table for: " + i)
    scoring(df_scoring, i).to_sql(i, engine, index=False, if_exists='replace')


for i in industrylist:
    print(i)
    print(scoring(df_scoring, i))

scoring(df_scoring, 'healthcare')

