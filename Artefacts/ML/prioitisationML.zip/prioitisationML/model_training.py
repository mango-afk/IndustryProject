#!/usr/bin/env python
# coding: utf-8

import numpy as np
from keras.layers import Dense, Activation, Embedding, Flatten, GlobalMaxPool1D, Dropout, Conv1D
import tensorflow as tf
from sklearn.preprocessing import LabelEncoder
from collections import Counter
from nltk.stem.snowball import SnowballStemmer
import nltk
from nltk import word_tokenize
from nltk.corpus import stopwords
from keras.layers import Dropout
from keras.callbacks import EarlyStopping
from keras.utils.np_utils import to_categorical
from sklearn.model_selection import train_test_split
from keras.layers import Dense, Embedding, LSTM, SpatialDropout1D
from keras.models import Sequential
from tensorflow.keras.preprocessing.sequence import pad_sequences
from keras.preprocessing.text import Tokenizer
import seaborn as sns
import matplotlib.pyplot as plt
import json
import pandas as pd
import requests
import re
import os
import sys
import pickle


def getdata(threat_cat):
    response = requests.get(
        "https://services.nvd.nist.gov/rest/json/cves/1.0/?resultsPerPage=2000&keyword="+threat_cat)
    Dictionary = response.json()
    id_ = []
    description = []
    score = []
    published_ = []
    lastModified_ = []
    dict_ = Dictionary['result']['CVE_Items']
    for element in dict_:
        id_.append(element['cve']['CVE_data_meta']['ID'])
        for i in element['cve']['description']['description_data']:
            description.append(i['value'])
        score.append(element['impact'])
        published_.append(element['publishedDate'])
        lastModified_.append(element['lastModifiedDate'])

    lists = [id_, description, score, published_, lastModified_]
    df = pd.DataFrame(lists).transpose()
    df.columns = ['id', 'description', 'score', 'published_', 'lastModified']

    df = df[df.score != {}]
    df.reset_index(drop=True, inplace=True)
    df_score = df["score"].apply(pd.Series)
    df_metricV3 = df_score["baseMetricV3"].apply(pd.Series)
    df_cvssV3 = df_metricV3["cvssV3"].apply(pd.Series)
    result_df = pd.concat([df, df_cvssV3], axis=1)
    return result_df


df_overflow = getdata('overflow')
#df_overflow = df_overflow[df_overflow.score != {}]
df_overflow['Category'] = 'Overflow'

df_DOS = getdata('denial of service')
df_DOS['Category'] = 'DOS'

df_code_exec = getdata('Code Execution')
df_code_exec['Category'] = 'Code Execution'

df_memory_corruption = getdata('memory corruption')
df_memory_corruption['Category'] = 'Memory Corruption'

df_sql = getdata('SQL Injection')
df_sql['Category'] = 'SQL Injection'

df_xss = getdata('XSS')
df_xss['Category'] = 'XSS'

df_directory_tra = getdata('Directory Traversal')
df_directory_tra['Category'] = 'Directory Traversal'

df_http = getdata('Http Response Splitting')
df_http['Category'] = 'Http Response Splitting'

df_bypass = getdata('bypass')
df_bypass['Category'] = 'Bypass'

df_gain_info = getdata('gain information')
df_gain_info['Category'] = 'Gain Info'

df_gain_privi = getdata('gain privilege')
df_gain_privi['Category'] = 'Gain Privilege'

df_CSRF = getdata('CSRF')
df_CSRF['Category'] = 'CSRF'

df_FI = getdata('File Inclusion')
df_FI['Category'] = 'File Inclusion'


result_df = pd.concat([df_overflow, df_DOS, df_code_exec, df_memory_corruption, df_sql, df_xss, df_directory_tra,
                      df_http, df_bypass, df_gain_info, df_gain_privi, df_CSRF, df_FI], ignore_index=True, sort=False)
result_df.loc[result_df['attackComplexity'].isnull() == True]
result_df.drop(
    result_df[result_df['attackComplexity'].isnull() == True].index, inplace=True)
result_df = result_df.reset_index(drop=True)
result_df


def decontract(sentence):
    # specific
    sentence = re.sub(r"won't", "will not", sentence)
    sentence = re.sub(r"can\'t", "can not", sentence)

    # general
    sentence = re.sub(r"n\'t", " not", sentence)
    sentence = re.sub(r"\'re", " are", sentence)
    sentence = re.sub(r"\'s", " is", sentence)
    sentence = re.sub(r"\'d", " would", sentence)
    sentence = re.sub(r"\'ll", " will", sentence)
    sentence = re.sub(r"\'t", " not", sentence)
    sentence = re.sub(r"\'ve", " have", sentence)
    sentence = re.sub(r"\'m", " am", sentence)
    return sentence


def cleanPunc(sentence):
    cleaned = re.sub(r'[?|!|\'|"|#]', r'', sentence)
    cleaned = re.sub(r'[.|,|)|(|\|/]', r' ', cleaned)
    cleaned = cleaned.strip()
    cleaned = cleaned.replace("\n", " ")
    return cleaned


def keepAlpha(sentence):
    alpha_sent = ""
    for word in sentence.split():
        alpha_word = re.sub('[^a-z A-Z]+', '', word)
        alpha_sent += alpha_word
        alpha_sent += " "
    alpha_sent = alpha_sent.strip()
    return alpha_sent


stop = stopwords.words('english')

stemmer = SnowballStemmer("english")


def stemming(sentence):
    stemSentence = ""
    for word in sentence.split():
        stem = stemmer.stem(word)
        stemSentence += stem
        stemSentence += " "
    stemSentence = stemSentence.strip()
    return stemSentence


result_df['description'] = result_df['description'].str.lower()
result_df['description'] = result_df['description'].apply(decontract)
result_df['description'] = result_df['description'].apply(cleanPunc)
result_df['description'] = result_df['description'].apply(keepAlpha)
result_df['description'] = result_df['description'].apply(
    lambda x: ' '.join([word for word in x.split() if word not in (stop)]))
result_df['description'] = result_df['description'].apply(stemming)


X_train, X_test, y_train, y_test = train_test_split(result_df['description'],
                                                    result_df['baseSeverity'],
                                                    stratify=result_df['baseSeverity'],
                                                    test_size=0.3, random_state=123)


num_words = 20000

tokenizer = Tokenizer(num_words=num_words, oov_token="unk")
tokenizer.fit_on_texts(X_train.tolist())


print(str(tokenizer.texts_to_sequences(['about the data'])))


X_train, X_valid, y_train, y_valid = train_test_split(X_train.tolist(),                                                      y_train.tolist(),
                                                      test_size=0.1,                                                      stratify=y_train.tolist(),                                                      random_state=123)


print('Train data len:'+str(len(X_train)))
print('Class distribution'+str(Counter(y_train)))
print('Valid data len:'+str(len(X_valid)))
print('Class distribution' + str(Counter(y_valid)))

x_train = np.array(tokenizer.texts_to_sequences(X_train))
x_valid = np.array(tokenizer.texts_to_sequences(X_valid))
x_test = np.array(tokenizer.texts_to_sequences(X_test.tolist()))

x_train = pad_sequences(x_train, padding='post', maxlen=200)
x_valid = pad_sequences(x_valid, padding='post', maxlen=200)
x_test = pad_sequences(x_test, padding='post', maxlen=200)

print(x_train[0])

le = LabelEncoder()

train_labels = le.fit_transform(y_train)
train_labels = np.asarray(tf.keras.utils.to_categorical(train_labels))
# print(train_labels)
valid_labels = le.transform(y_valid)
valid_labels = np.asarray(tf.keras.utils.to_categorical(valid_labels))

test_labels = le.transform(y_test.tolist())
test_labels = np.asarray(tf.keras.utils.to_categorical(test_labels))
list(le.classes_)


train_ds = tf.data.Dataset.from_tensor_slices((x_train, train_labels))
valid_ds = tf.data.Dataset.from_tensor_slices((x_valid, valid_labels))
test_ds = tf.data.Dataset.from_tensor_slices((x_test, test_labels))


print(y_train[:10])
train_labels = le.fit_transform(y_train)
print('Text to number')
print(train_labels[:10])
train_labels = np.asarray(tf.keras.utils.to_categorical(train_labels))
print('Number to category')
print(train_labels[:10])


count = 0
print('======Train dataset ====')
for value, label in train_ds:
    count += 1
    print(value, label)
    if count == 3:
        break
count = 0
print('======Validation dataset ====')
for value, label in valid_ds:
    count += 1
    print(value, label)
    if count == 3:
        break
print('======Test dataset ====')
for value, label in test_ds:
    count += 1
    print(value, label)
    if count == 3:
        break

max_words = 20000
filter_length = 300
maxlen = 200

model = Sequential()
model.add(Embedding(max_words, 20, input_length=maxlen))
model.add(Dense(512, activation='relu',
          kernel_regularizer=tf.keras.regularizers.l2(0.001)))
# model.add(Dropout(0.5))
model.add(Conv1D(filter_length, 3, padding='valid',
          activation='relu', strides=1))
model.add(GlobalMaxPool1D())
model.add(Dense(4))
model.add(Activation('sigmoid'))
# model.add(Dropout(0.5))

model.compile(optimizer='adam', loss='binary_crossentropy',
              metrics=[tf.keras.metrics.AUC()])

callbacks = [
    tf.keras.callbacks.ReduceLROnPlateau(),
    tf.keras.callbacks.ModelCheckpoint(
        filepath='model-conv1d.h5', save_best_only=True)
]
model.summary()


epochs = 30
# Fit the model using the train and test datasets.
history = model.fit(train_ds.shuffle(2000).batch(128),
                    epochs=epochs,
                    validation_data=valid_ds.batch(128),
                    verbose=1)


# Plot
plt.plot(history.history['loss'], label=' training data')
plt.plot(history.history['val_loss'], label='validation data)')
plt.title('Loss for Text Classification')
plt.ylabel('Loss value')
plt.xlabel('No. epoch')
plt.legend(loc="upper left")
plt.show()


plt.plot(history.history['auc'], label=' (training data)')
plt.plot(history.history['val_auc'],
         label='CategoricalCrossentropy (validation data)')
plt.title('CategoricalAccuracy for Text Classification')
plt.ylabel('CategoricalAccuracy value')
plt.xlabel('No. epoch')
plt.legend(loc="upper left")
plt.show()

# Save the neural network model
save_path = sys.path[0]
file_name = 'tf_cnnmodel'
modelsave = os.path.join(sys.path[0], file_name)
print(modelsave)
model.save(modelsave)


# Save the tokenizer used
with open('tokenizer.pickle', 'wb') as handle:
    pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)
